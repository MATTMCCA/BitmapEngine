
# Sample Prints

For personal documentation, same image's printed on 300dpi & 200dpi thermal printer.

### Notes:

Thermal head has ware, this can been seen in the print as "light streaks".